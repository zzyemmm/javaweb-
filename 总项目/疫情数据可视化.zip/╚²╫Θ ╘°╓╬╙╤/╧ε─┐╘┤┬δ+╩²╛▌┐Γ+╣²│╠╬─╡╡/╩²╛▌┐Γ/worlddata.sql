/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : db_data

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 24/01/2021 00:04:34
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for worlddata
-- ----------------------------
DROP TABLE IF EXISTS `worlddata`;
CREATE TABLE `worlddata`  (
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `continent` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `y` int(0) NULL DEFAULT NULL,
  `date` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `confirmAdd` int(0) NULL DEFAULT NULL,
  `confirm` int(0) NULL DEFAULT NULL,
  `dead` int(0) NULL DEFAULT NULL,
  `heal` int(0) NULL DEFAULT NULL,
  `nowConfirm` int(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of worlddata
-- ----------------------------
INSERT INTO `worlddata` VALUES ('美国', '北美洲', 2021, '01.23', 192065, 25390042, 424177, 15222719, 9743146);
INSERT INTO `worlddata` VALUES ('西班牙', '欧洲', 2021, '01.23', 42885, 2603472, 55441, 196958, 2351073);
INSERT INTO `worlddata` VALUES ('法国', '欧洲', 2020, '12.13', 0, 2405255, 57671, 181581, 2166003);
INSERT INTO `worlddata` VALUES ('秘鲁', '南美洲', 2020, '08.02', 0, 422183, 19408, 290835, 111940);
INSERT INTO `worlddata` VALUES ('英国', '欧洲', 2020, '04.17', 0, 104145, 13759, 375, 90011);
INSERT INTO `worlddata` VALUES ('意大利', '欧洲', 2020, '03.30', 0, 97689, 10779, 13030, 73880);
INSERT INTO `worlddata` VALUES ('德国', '欧洲', 2020, '03.30', 0, 63929, 560, 9211, 54158);
INSERT INTO `worlddata` VALUES ('伊朗', '亚洲', 2020, '03.31', 0, 44606, 2898, 14656, 27052);
INSERT INTO `worlddata` VALUES ('加拿大', '北美洲', 2020, '04.25', 0, 44526, 2386, 15479, 26661);
INSERT INTO `worlddata` VALUES ('瑞士', '欧洲', 2020, '03.30', 0, 15526, 312, 1823, 13391);
INSERT INTO `worlddata` VALUES ('奥地利', '欧洲', 2020, '04.17', 0, 14476, 410, 8986, 5080);
INSERT INTO `worlddata` VALUES ('比利时', '欧洲', 2020, '03.30', 0, 11899, 513, 1527, 9859);
INSERT INTO `worlddata` VALUES ('荷兰', '欧洲', 2020, '03.30', 0, 11814, 864, 253, 10697);
INSERT INTO `worlddata` VALUES ('韩国', '亚洲', 2020, '04.02', 0, 9976, 169, 5828, 3979);
INSERT INTO `worlddata` VALUES ('土耳其', '亚洲', 2020, '03.30', 0, 9217, 131, 105, 8981);
INSERT INTO `worlddata` VALUES ('塞尔维亚', '欧洲', 2020, '04.30', 0, 8724, 173, 1292, 7259);
INSERT INTO `worlddata` VALUES ('葡萄牙', '欧洲', 2020, '03.30', 0, 6408, 140, 43, 6225);
INSERT INTO `worlddata` VALUES ('以色列', '亚洲', 2020, '03.30', 0, 4347, 15, 139, 4193);
INSERT INTO `worlddata` VALUES ('挪威', '欧洲', 2020, '03.30', 0, 4284, 26, 7, 4251);
INSERT INTO `worlddata` VALUES ('巴西', '南美洲', 2020, '03.30', 0, 4256, 136, 6, 4114);
INSERT INTO `worlddata` VALUES ('澳大利亚', '大洋洲', 2020, '03.30', 0, 4245, 18, 244, 3983);
INSERT INTO `worlddata` VALUES ('瑞典', '欧洲', 2020, '03.30', 0, 3700, 110, 16, 3574);
INSERT INTO `worlddata` VALUES ('捷克', '欧洲', 2020, '03.30', 0, 2817, 16, 11, 2790);
INSERT INTO `worlddata` VALUES ('丹麦', '欧洲', 2020, '03.30', 0, 2724, 72, 73, 2579);
INSERT INTO `worlddata` VALUES ('马来西亚', '亚洲', 2020, '03.30', 0, 2626, 37, 479, 2110);
INSERT INTO `worlddata` VALUES ('爱尔兰', '欧洲', 2020, '03.30', 0, 2615, 46, 5, 2564);
INSERT INTO `worlddata` VALUES ('智利', '南美洲', 2020, '03.30', 0, 2449, 8, 156, 2285);
INSERT INTO `worlddata` VALUES ('卢森堡', '欧洲', 2020, '03.30', 0, 1988, 22, 40, 1926);
INSERT INTO `worlddata` VALUES ('罗马尼亚', '欧洲', 2020, '03.30', 0, 1952, 46, 206, 1700);
INSERT INTO `worlddata` VALUES ('厄瓜多尔', '南美洲', 2020, '03.30', 0, 1924, 58, 3, 1863);
INSERT INTO `worlddata` VALUES ('波兰', '欧洲', 2020, '03.30', 0, 1905, 26, 7, 1872);
INSERT INTO `worlddata` VALUES ('俄罗斯', '欧洲', 2020, '03.30', 0, 1836, 9, 66, 1761);
INSERT INTO `worlddata` VALUES ('日本本土', '亚洲', 2020, '03.28', 0, 1724, 52, 372, 1300);
INSERT INTO `worlddata` VALUES ('巴基斯坦', '亚洲', 2020, '03.30', 0, 1625, 20, 29, 1576);
INSERT INTO `worlddata` VALUES ('菲律宾', '亚洲', 2020, '03.30', 0, 1546, 78, 42, 1426);
INSERT INTO `worlddata` VALUES ('泰国', '亚洲', 2020, '03.30', 0, 1524, 9, 127, 1388);
INSERT INTO `worlddata` VALUES ('沙特阿拉伯', '亚洲', 2020, '03.30', 0, 1453, 8, 115, 1330);
INSERT INTO `worlddata` VALUES ('印度尼西亚', '亚洲', 2020, '03.30', 0, 1414, 122, 75, 1217);
INSERT INTO `worlddata` VALUES ('南非', '非洲', 2020, '03.30', 0, 1280, 2, 31, 1247);
INSERT INTO `worlddata` VALUES ('芬兰', '欧洲', 2020, '03.30', 0, 1240, 11, 10, 1219);
INSERT INTO `worlddata` VALUES ('希腊', '欧洲', 2020, '03.29', 0, 1156, 38, 52, 1066);
INSERT INTO `worlddata` VALUES ('印度', '亚洲', 2020, '03.30', 0, 1071, 29, 99, 943);
INSERT INTO `worlddata` VALUES ('冰岛', '欧洲', 2020, '03.30', 0, 1020, 2, 135, 883);
INSERT INTO `worlddata` VALUES ('墨西哥', '北美洲', 2020, '03.30', 0, 993, 20, 4, 969);
INSERT INTO `worlddata` VALUES ('巴拿马', '北美洲', 2020, '03.30', 0, 989, 24, 4, 961);
INSERT INTO `worlddata` VALUES ('多米尼加', '北美洲', 2020, '03.30', 0, 901, 42, 4, 855);
INSERT INTO `worlddata` VALUES ('新加坡', '亚洲', 2020, '03.30', 0, 879, 3, 228, 648);
INSERT INTO `worlddata` VALUES ('阿根廷', '南美洲', 2020, '03.30', 0, 820, 80, 72, 668);
INSERT INTO `worlddata` VALUES ('克罗地亚', '欧洲', 2020, '03.30', 0, 713, 6, 55, 652);
INSERT INTO `worlddata` VALUES ('钻石号邮轮', '其他', 2020, '03.31', 0, 712, 11, 603, 98);
INSERT INTO `worlddata` VALUES ('哥伦比亚', '南美洲', 2020, '03.30', 0, 702, 10, 10, 682);
INSERT INTO `worlddata` VALUES ('斯洛文尼亚', '欧洲', 2020, '03.29', 0, 684, 9, 10, 665);
INSERT INTO `worlddata` VALUES ('爱沙尼亚', '欧洲', 2020, '03.29', 0, 645, 1, 20, 624);
INSERT INTO `worlddata` VALUES ('卡塔尔', '亚洲', 2020, '03.30', 0, 634, 1, 48, 585);
INSERT INTO `worlddata` VALUES ('阿联酋', '亚洲', 2020, '03.30', 0, 611, 5, 61, 545);
INSERT INTO `worlddata` VALUES ('埃及', '非洲', 2020, '03.30', 0, 609, 40, 132, 437);
INSERT INTO `worlddata` VALUES ('新西兰', '大洋洲', 2020, '03.30', 0, 589, 1, 56, 532);
INSERT INTO `worlddata` VALUES ('阿塞拜疆', '亚洲', 2020, '04.05', 0, 584, 5, 32, 547);
INSERT INTO `worlddata` VALUES ('伊拉克', '亚洲', 2020, '03.29', 0, 547, 42, 143, 362);
INSERT INTO `worlddata` VALUES ('摩洛哥', '非洲', 2020, '03.30', 0, 516, 27, 13, 476);
INSERT INTO `worlddata` VALUES ('巴林', '亚洲', 2020, '03.30', 0, 515, 4, 279, 232);
INSERT INTO `worlddata` VALUES ('阿尔及利亚', '非洲', 2020, '03.30', 0, 511, 31, 32, 448);
INSERT INTO `worlddata` VALUES ('亚美尼亚', '亚洲', 2020, '03.30', 0, 481, 3, 30, 448);
INSERT INTO `worlddata` VALUES ('乌克兰', '欧洲', 2020, '03.30', 0, 480, 11, 6, 463);
INSERT INTO `worlddata` VALUES ('立陶宛', '欧洲', 2020, '03.29', 0, 460, 7, 1, 452);
INSERT INTO `worlddata` VALUES ('匈牙利', '欧洲', 2020, '03.30', 0, 447, 15, 34, 398);
INSERT INTO `worlddata` VALUES ('黎巴嫩', '亚洲', 2020, '03.30', 0, 446, 11, 32, 403);
INSERT INTO `worlddata` VALUES ('拉脱维亚', '欧洲', 2020, '03.30', 0, 347, 0, 1, 346);
INSERT INTO `worlddata` VALUES ('斯洛伐克', '欧洲', 2020, '03.30', 0, 336, 0, 2, 334);
INSERT INTO `worlddata` VALUES ('安道尔', '欧洲', 2020, '03.29', 0, 334, 6, 6, 322);
INSERT INTO `worlddata` VALUES ('波黑', '欧洲', 2020, '03.30', 0, 324, 6, 8, 310);
INSERT INTO `worlddata` VALUES ('保加利亚', '欧洲', 2020, '03.28', 0, 313, 3, 4, 306);
INSERT INTO `worlddata` VALUES ('突尼斯', '非洲', 2020, '03.30', 0, 312, 8, 2, 302);
INSERT INTO `worlddata` VALUES ('乌拉圭', '南美洲', 2020, '03.30', 0, 309, 1, 6, 302);
INSERT INTO `worlddata` VALUES ('哈萨克斯坦', '亚洲', 2020, '03.30', 0, 302, 1, 21, 280);
INSERT INTO `worlddata` VALUES ('哥斯达黎加', '北美洲', 2020, '03.29', 0, 295, 2, 3, 290);
INSERT INTO `worlddata` VALUES ('科威特', '亚洲', 2020, '03.30', 0, 266, 0, 72, 194);
INSERT INTO `worlddata` VALUES ('约旦', '亚洲', 2020, '03.30', 0, 259, 3, 18, 238);
INSERT INTO `worlddata` VALUES ('北马其顿', '欧洲', 2020, '03.30', 0, 259, 6, 3, 250);
INSERT INTO `worlddata` VALUES ('摩尔多瓦', '欧洲', 2020, '03.29', 0, 231, 2, 2, 227);
INSERT INTO `worlddata` VALUES ('圣马力诺', '欧洲', 2020, '03.30', 0, 224, 22, 6, 196);
INSERT INTO `worlddata` VALUES ('布基纳法索', '非洲', 2020, '03.30', 0, 222, 12, 23, 187);
INSERT INTO `worlddata` VALUES ('塞浦路斯', '亚洲', 2020, '03.29', 0, 214, 6, 15, 193);
INSERT INTO `worlddata` VALUES ('阿尔巴尼亚', '欧洲', 2020, '03.30', 0, 212, 10, 33, 169);
INSERT INTO `worlddata` VALUES ('越南', '亚洲', 2020, '03.30', 0, 194, 0, 52, 142);
INSERT INTO `worlddata` VALUES ('阿曼', '亚洲', 2020, '03.30', 0, 179, 0, 29, 150);
INSERT INTO `worlddata` VALUES ('科特迪瓦', '非洲', 2020, '03.30', 0, 165, 1, 4, 160);
INSERT INTO `worlddata` VALUES ('塞内加尔', '非洲', 2020, '03.30', 0, 162, 0, 28, 134);
INSERT INTO `worlddata` VALUES ('加纳', '非洲', 2020, '03.29', 0, 152, 5, 2, 145);
INSERT INTO `worlddata` VALUES ('马耳他', '欧洲', 2020, '03.29', 0, 149, 0, 2, 147);
INSERT INTO `worlddata` VALUES ('乌兹别克斯坦', '亚洲', 2020, '03.30', 0, 149, 2, 7, 140);
INSERT INTO `worlddata` VALUES ('阿富汗', '亚洲', 2020, '03.30', 0, 145, 4, 2, 139);
INSERT INTO `worlddata` VALUES ('喀麦隆', '非洲', 2020, '03.30', 0, 142, 6, 5, 131);
INSERT INTO `worlddata` VALUES ('洪都拉斯', '北美洲', 2020, '03.30', 0, 139, 1, 3, 135);
INSERT INTO `worlddata` VALUES ('文莱', '亚洲', 2020, '03.30', 0, 127, 1, 38, 88);
INSERT INTO `worlddata` VALUES ('斯里兰卡', '亚洲', 2020, '03.30', 0, 122, 1, 11, 110);
INSERT INTO `worlddata` VALUES ('委内瑞拉', '南美洲', 2020, '03.29', 0, 119, 2, 39, 78);
INSERT INTO `worlddata` VALUES ('古巴', '北美洲', 2020, '03.29', 0, 119, 3, 4, 112);
INSERT INTO `worlddata` VALUES ('尼日利亚', '非洲', 2020, '03.30', 0, 111, 1, 3, 107);
INSERT INTO `worlddata` VALUES ('毛里求斯', '非洲', 2020, '03.29', 0, 107, 2, 0, 105);
INSERT INTO `worlddata` VALUES ('巴勒斯坦', '亚洲', 2020, '03.30', 0, 106, 1, 18, 87);
INSERT INTO `worlddata` VALUES ('柬埔寨', '亚洲', 2020, '03.30', 0, 103, 0, 21, 82);
INSERT INTO `worlddata` VALUES ('格鲁吉亚', '亚洲', 2020, '03.30', 0, 98, 0, 18, 80);
INSERT INTO `worlddata` VALUES ('白俄罗斯', '欧洲', 2020, '03.29', 0, 94, 0, 32, 62);
INSERT INTO `worlddata` VALUES ('黑山', '欧洲', 2020, '03.30', 0, 85, 1, 0, 84);
INSERT INTO `worlddata` VALUES ('吉尔吉斯斯坦', '亚洲', 2020, '03.29', 0, 84, 0, 0, 84);
INSERT INTO `worlddata` VALUES ('玻利维亚', '南美洲', 2020, '03.29', 0, 81, 0, 0, 81);
INSERT INTO `worlddata` VALUES ('刚果（金）', '非洲', 2020, '03.30', 0, 81, 8, 3, 70);
INSERT INTO `worlddata` VALUES ('卢旺达', '非洲', 2020, '03.30', 0, 70, 0, 0, 70);
INSERT INTO `worlddata` VALUES ('巴拉圭', '南美洲', 2020, '03.30', 0, 64, 3, 1, 60);
INSERT INTO `worlddata` VALUES ('列支敦士登公国', '欧洲', 2020, '03.28', 0, 56, 0, 0, 56);
INSERT INTO `worlddata` VALUES ('肯尼亚', '非洲', 2020, '03.30', 0, 50, 1, 1, 48);
INSERT INTO `worlddata` VALUES ('孟加拉', '亚洲', 2020, '03.30', 0, 49, 5, 19, 25);
INSERT INTO `worlddata` VALUES ('摩纳哥', '欧洲', 2020, '03.29', 0, 43, 0, 1, 42);
INSERT INTO `worlddata` VALUES ('马达加斯加', '非洲', 2020, '03.29', 0, 43, 0, 0, 43);
INSERT INTO `worlddata` VALUES ('赞比亚', '非洲', 2020, '03.30', 0, 35, 0, 0, 35);
INSERT INTO `worlddata` VALUES ('危地马拉', '北美洲', 2020, '03.29', 0, 34, 1, 10, 23);
INSERT INTO `worlddata` VALUES ('乌干达', '非洲', 2020, '03.30', 0, 33, 0, 0, 33);
INSERT INTO `worlddata` VALUES ('多哥', '非洲', 2020, '03.30', 0, 30, 1, 7, 22);
INSERT INTO `worlddata` VALUES ('圭亚那', '南美洲', 2020, '03.29', 0, 28, 1, 6, 21);
INSERT INTO `worlddata` VALUES ('吉布提', '非洲', 2020, '03.30', 0, 25, 0, 0, 25);
INSERT INTO `worlddata` VALUES ('马里', '非洲', 2020, '03.30', 0, 25, 2, 0, 23);
INSERT INTO `worlddata` VALUES ('埃塞俄比亚', '非洲', 2020, '03.30', 0, 23, 0, 2, 21);
INSERT INTO `worlddata` VALUES ('缅甸', '亚洲', 2020, '04.03', 0, 20, 1, 0, 19);
INSERT INTO `worlddata` VALUES ('刚果（布）', '非洲', 2020, '03.28', 0, 19, 0, 0, 19);
INSERT INTO `worlddata` VALUES ('坦桑尼亚', '非洲', 2020, '03.30', 0, 19, 0, 1, 18);
INSERT INTO `worlddata` VALUES ('尼日尔', '非洲', 2020, '03.30', 0, 18, 1, 0, 17);
INSERT INTO `worlddata` VALUES ('马尔代夫', '亚洲', 2020, '03.30', 0, 17, 0, 11, 6);
INSERT INTO `worlddata` VALUES ('几内亚', '非洲', 2020, '03.30', 0, 16, 0, 1, 15);
INSERT INTO `worlddata` VALUES ('赤道几内亚', '非洲', 2020, '03.30', 0, 14, 0, 0, 14);
INSERT INTO `worlddata` VALUES ('蒙古', '亚洲', 2020, '03.28', 0, 12, 0, 0, 12);
INSERT INTO `worlddata` VALUES ('厄立特里亚', '非洲', 2020, '03.30', 0, 12, 0, 0, 12);
INSERT INTO `worlddata` VALUES ('纳米比亚', '非洲', 2020, '03.29', 0, 11, 0, 0, 11);
INSERT INTO `worlddata` VALUES ('叙利亚', '亚洲', 2020, '03.30', 0, 10, 1, 0, 9);
INSERT INTO `worlddata` VALUES ('斯威士兰', '非洲', 2020, '03.29', 0, 9, 0, 0, 9);
INSERT INTO `worlddata` VALUES ('海地', '北美洲', 2020, '03.28', 0, 8, 0, 0, 8);
INSERT INTO `worlddata` VALUES ('塞舌尔', '非洲', 2020, '03.29', 0, 8, 0, 0, 8);
INSERT INTO `worlddata` VALUES ('莫桑比克', '非洲', 2020, '03.28', 0, 8, 0, 0, 8);
INSERT INTO `worlddata` VALUES ('老挝', '亚洲', 2020, '03.29', 0, 8, 0, 0, 8);
INSERT INTO `worlddata` VALUES ('苏里南', '南美洲', 2020, '03.28', 0, 8, 0, 0, 8);
INSERT INTO `worlddata` VALUES ('安提瓜和巴布达', '北美洲', 2020, '03.28', 0, 7, 0, 0, 7);
INSERT INTO `worlddata` VALUES ('加蓬', '非洲', 2020, '03.27', 0, 7, 1, 0, 6);
INSERT INTO `worlddata` VALUES ('安哥拉', '非洲', 2020, '03.30', 0, 7, 2, 0, 5);
INSERT INTO `worlddata` VALUES ('津巴布韦', '非洲', 2020, '03.28', 0, 7, 1, 0, 6);
INSERT INTO `worlddata` VALUES ('苏丹', '非洲', 2020, '03.30', 0, 6, 1, 0, 5);
INSERT INTO `worlddata` VALUES ('佛得角', '非洲', 2020, '03.29', 0, 6, 1, 0, 5);
INSERT INTO `worlddata` VALUES ('梵蒂冈', '欧洲', 2020, '03.29', 0, 6, 0, 0, 6);
INSERT INTO `worlddata` VALUES ('贝宁', '非洲', 2020, '03.28', 0, 6, 0, 0, 6);
INSERT INTO `worlddata` VALUES ('中非共和国', '非洲', 2020, '03.28', 0, 6, 0, 0, 6);
INSERT INTO `worlddata` VALUES ('乍得', '非洲', 2020, '03.29', 0, 5, 0, 0, 5);
INSERT INTO `worlddata` VALUES ('尼泊尔', '亚洲', 2020, '03.25', 0, 5, 0, 1, 4);
INSERT INTO `worlddata` VALUES ('毛里塔尼亚', '非洲', 2020, '03.30', 0, 5, 0, 2, 3);
INSERT INTO `worlddata` VALUES ('不丹', '亚洲', 2020, '03.30', 0, 4, 0, 0, 4);
INSERT INTO `worlddata` VALUES ('冈比亚', '非洲', 2020, '03.30', 0, 4, 1, 0, 3);
INSERT INTO `worlddata` VALUES ('尼加拉瓜', '北美洲', 2020, '03.28', 0, 4, 1, 0, 3);
INSERT INTO `worlddata` VALUES ('索马里', '非洲', 2020, '03.27', 0, 3, 0, 0, 3);
INSERT INTO `worlddata` VALUES ('利比里亚', '非洲', 2020, '03.21', 0, 3, 0, 0, 3);
INSERT INTO `worlddata` VALUES ('几内亚比绍', '非洲', 2020, '03.25', 0, 2, 0, 0, 2);
INSERT INTO `worlddata` VALUES ('伯利兹', '北美洲', 2020, '03.28', 0, 2, 0, 0, 2);
INSERT INTO `worlddata` VALUES ('东帝汶', '亚洲', 2020, '03.21', 0, 1, 0, 0, 1);
INSERT INTO `worlddata` VALUES ('巴布亚新几内亚', '大洋洲', 2020, '03.21', 0, 1, 0, 0, 1);

SET FOREIGN_KEY_CHECKS = 1;
