/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : db_data

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 24/01/2021 00:04:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for allworlddata
-- ----------------------------
DROP TABLE IF EXISTS `allworlddata`;
CREATE TABLE `allworlddata`  (
  `nowConfirm` int(0) NULL DEFAULT NULL,
  `confirm` int(0) NULL DEFAULT NULL,
  `cureCount` int(0) NULL DEFAULT NULL,
  `deadCount` int(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of allworlddata
-- ----------------------------
INSERT INTO `allworlddata` VALUES (27319253, 98727658, 69296296, 2112109);

SET FOREIGN_KEY_CHECKS = 1;
