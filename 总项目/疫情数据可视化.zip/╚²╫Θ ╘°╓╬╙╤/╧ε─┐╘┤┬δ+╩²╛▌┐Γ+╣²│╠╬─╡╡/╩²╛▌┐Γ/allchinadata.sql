/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : db_data

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 24/01/2021 16:28:13
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for allchinadata
-- ----------------------------
DROP TABLE IF EXISTS `allchinadata`;
CREATE TABLE `allchinadata`  (
  `name` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `nowConfirm` int(0) NULL DEFAULT NULL,
  `confirm` int(0) NULL DEFAULT NULL,
  `cureCount` int(0) NULL DEFAULT NULL,
  `deadCount` int(0) NULL DEFAULT NULL,
  `OverseasIn` int(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of allchinadata
-- ----------------------------
INSERT INTO `allchinadata` VALUES ('中国', 2726, 99937, 92401, 4810, 4604);

SET FOREIGN_KEY_CHECKS = 1;
